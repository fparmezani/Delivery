--INIT#obterTaxaEntregaTipo#

SELECT 
    *
FROM 
	taxaentregatipo

--END#obterTaxaEntregaTipo#